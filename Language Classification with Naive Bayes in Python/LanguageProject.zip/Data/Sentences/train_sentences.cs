Upozorňujeme, že jejím cílem je šetřit penězi za administrativní výdaje.
Zcela otevřeně přiznám, že ne vždy rozumím extrémně složitým vědeckým analýzám, které dostávám.
Při práci na této zprávě bylo třeba, abych pracovala právě s touto "představivostí".
A nakonec, plně podporuji myšlenku sjednotit vědeckovýzkumný sektor v energetické oblasti, jakožto klíčový prvek dané dlouhodobé politiky.
To je vážná věc.
Z tohoto hlediska zcela souhlasím s připomínkami pana Verheugena.
Rozprava je ukončena.
Vzhledem k významu, které má stavebnictví pro evropské hospodářství, je nutné odstranit technické překážky bránící obchodu se stavebními výrobky v zájmu zlepšení jejich volného pohybu na vnitřním trhu.
V roce 2009 je to popáté, kdy byly z tohoto fondu uvolněny prostředky, přičemž byla využita celková částka 53 milionů EUR z plánované výše 500 milionů EUR.
Ve svém vystoupení bych chtěla ocenit návrhy paní zpravodajky Anny Záborské, které doporučují uznat vedle tradiční oficiální výdělečné činnosti i mnohé formy činnosti nevýdělečné, která se v rámci solidarity mezi generacemi vykonává v rodinách.
